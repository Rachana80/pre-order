<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://restropress.com
 * @since      1.0.0
 *
 * @package    Pre_Order_For_Restropress
 * @subpackage Pre_Order_For_Restropress/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

