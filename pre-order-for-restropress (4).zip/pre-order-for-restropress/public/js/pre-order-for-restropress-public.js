jQuery(document).ready(function ($) {
      //set cookies on checkout page onchange service type
      $('.rp-checkout-service-option .rpress_get_delivery_dates')
        .on('change', function () {
          $('.rp-checkout-service-option .rpress-delivery-opt-update')
            .trigger('click');
        })
});