=== RestroPress - Pre Order ===
Contributors: magnigenie,rachana1622
Donate link: https://paypal.me/magnigeeks
Tags:  RestroPress, pre order, food orderring, e-commerce
Requires at least: 5.4
Tested up to: 6.3.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

With RestroPress - Pre Order plugin, you can reserve your favorite products before they hit the shelves. Get ahead of the crowd and enjoy these benefits:

Early Access: Secure exclusive access to upcoming releases.
Guaranteed Availability: Ensure you get the products you want, even for limited-edition items.
Zero FOMO: Say goodbye to the fear of missing out—your order is locked in.
Convenient Shopping: Skip the rush and have your items delivered hassle-free.

Pre-ordering is the smart way to shop. Don't wait, be a trendsetter today!

== Installation ==

1. Login to your WordPress dashboard and navigate to Plugins > Add New
2. Search for "RestroPress - Pre Order".
3. Click install.
4. Click activate.
5. Once the plugin is installed then you can see RestroPress on the left navigation bar of WordPress Dashboard.

== Changelog ==

= 1.0.0 =
* Initial version released